package com.example.screenstudysolver;

import java.util.*;
import java.util.regex.*;

public final class MathSolver {
    private MathSolver() {}

    public static String solve(String raw) {
        if (raw == null) return "—";
        String s = normalize(raw);
        if (s.isEmpty()) return "—";
        try {
            if (s.contains("=")) {
                String linear = solveLinear(s);
                if (linear != null) return linear;
                String quad = solveQuadratic(s);
                if (quad != null) return quad;
            }
            String expr = firstExpression(s);
            if (expr != null && expr.matches("[0-9+\\-*/().%^ ]+")) {
                double v = evaluate(expr);
                return format(v);
            }
        } catch (Exception ignored) {}
        return "No supported equation found";
    }

    private static String normalize(String s) {
        return s.replace('×','*').replace('÷','/').replace('−','-').replace('–','-')
                .replace("²","^2").replace("³","^3").replaceAll("\\s+", " ").trim();
    }

    private static String solveLinear(String s) {
        if (!s.matches(".*[xX].*=.*")) return null;
        String[] sides = s.toLowerCase(Locale.US).split("=", 2);
        if (sides.length != 2) return null;
        double[] L = linearCoeffs(sides[0]);
        double[] R = linearCoeffs(sides[1]);
        double a = L[0]-R[0], b = L[1]-R[1];
        if (Math.abs(a) < 1e-12) return null;
        return "x = " + format(-b/a);
    }

    private static double[] linearCoeffs(String s) {
        s = s.replace("-", "+-"); if (s.startsWith("+-")) s = s.substring(1);
        double a=0,b=0;
        for (String term : s.split("\\+")) {
            term = term.trim(); if (term.isEmpty()) continue;
            if (term.contains("x")) {
                String c = term.replace("x","").trim();
                if (c.isEmpty() || c.equals("+")) c="1";
                if (c.equals("-")) c="-1";
                a += Double.parseDouble(c);
            } else b += Double.parseDouble(term);
        }
        return new double[]{a,b};
    }

    private static String solveQuadratic(String s) {
        Matcher m = Pattern.compile("([+-]?\\d*\\.?\\d*)\\s*x\\^2\\s*([+-]\\s*\\d*\\.?\\d*)\\s*x\\s*([+-]\\s*\\d*\\.?\\d*)?\\s*=\\s*0", Pattern.CASE_INSENSITIVE).matcher(s.replace(" ",""));
        if (!m.find()) return null;
        double a = coeff(m.group(1),1), b=coeff(m.group(2),0), c=coeff(m.group(3),0);
        if (Math.abs(a)<1e-12) return null;
        double d=b*b-4*a*c;
        if (d < 0) return "No real roots";
        if (Math.abs(d)<1e-12) return "x = " + format(-b/(2*a));
        double r=Math.sqrt(d);
        return "x = " + format((-b+r)/(2*a)) + ", " + format((-b-r)/(2*a));
    }

    private static double coeff(String s,double def) {
        if (s==null || s.isEmpty() || s.equals("+")) return def;
        if (s.equals("-")) return -def;
        if (!s.startsWith("+") && !s.startsWith("-")) return Double.parseDouble(s);
        return Double.parseDouble(s.replace(" ",""));
    }

    private static String firstExpression(String s) {
        Matcher m=Pattern.compile("[0-9+\\-*/().%^ ]+").matcher(s);
        String best=null; while(m.find()) if (m.group().trim().length()>0) best=m.group().trim();
        return best;
    }

    private static double evaluate(String s) {
        List<String> out=new ArrayList<>(), ops=new ArrayList<>();
        Matcher m=Pattern.compile("\\d+(?:\\.\\d+)?|[()+\\-*/%^]").matcher(s);
        int pos=0; boolean expectUnary=true;
        while(m.find()) {
            String t=m.group();
            if (t.equals("-") && expectUnary) { out.add("0"); }
            if (t.matches("\\d+(?:\\.\\d+)?")) { out.add(t); expectUnary=false; continue; }
            if (t.equals("(")) { ops.add(t); expectUnary=true; continue; }
            if (t.equals(")")) { while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("(")) out.add(ops.remove(ops.size()-1)); if(!ops.isEmpty())ops.remove(ops.size()-1); expectUnary=false; continue; }
            int p=prec(t); while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("(")&&prec(ops.get(ops.size()-1))>=p) out.add(ops.remove(ops.size()-1)); ops.add(t); expectUnary=true;
            pos=m.end();
        }
        while(!ops.isEmpty()) out.add(ops.remove(ops.size()-1));
        Deque<Double> st=new ArrayDeque<>(); for(String t:out){ if(t.matches("\\d+(?:\\.\\d+)?"))st.push(Double.parseDouble(t)); else {double b=st.pop(),a=st.pop(); switch(t){case "+":st.push(a+b);break;case "-":st.push(a-b);break;case "*":st.push(a*b);break;case "/":st.push(a/b);break;case "%":st.push(a%b);break;case "^":st.push(Math.pow(a,b));break;}}} return st.pop();
    }
    private static int prec(String s){ if(s.equals("+")||s.equals("-"))return 1; if(s.equals("*")||s.equals("/")||s.equals("%"))return 2; if(s.equals("^"))return 3; return 0; }
    private static String format(double v){ if(Double.isNaN(v)||Double.isInfinite(v))return "Undefined"; if(Math.abs(v-Math.rint(v))<1e-10)return String.format(Locale.US,"%.0f",v); return String.format(Locale.US,"%.6f",v).replaceAll("0+$","").replaceAll("\\.$",""); }
}
