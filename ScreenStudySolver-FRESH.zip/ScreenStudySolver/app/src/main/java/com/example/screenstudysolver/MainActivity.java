package com.example.screenstudysolver;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private static final int REQ_OVERLAY = 1002;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);
        root.setBackgroundColor(0xFF101828);

        TextView title = new TextView(this);
        title.setText("Screen Study Solver");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(24);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("Floating OCR + maths solver for study/practice. It reads visible screen text and shows the detected result in a movable overlay.");
        info.setTextColor(0xFFD1D5DB);
        info.setTextSize(15);
        info.setPadding(0, 20, 0, 20);
        root.addView(info);

        Button start = new Button(this);
        start.setText("START FLOATING SOLVER");
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("STOP SOLVER");
        root.addView(stop);

        TextView note = new TextView(this);
        note.setText("First start asks for overlay permission and Android screen-capture permission.");
        note.setTextColor(0xFF9CA3AF);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);

        setContentView(root);

        start.setOnClickListener(v -> startFlow());
        stop.setOnClickListener(v -> stopService(new Intent(this, ScreenCaptureService.class)));
    }

    private void startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }
        requestCapture();
    }

    private void requestCapture() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) requestCapture();
            else Toast.makeText(this, "Overlay permission is required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "Screen capture permission was cancelled.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, ScreenCaptureService.class);
            svc.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
            svc.putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc); else startService(svc);
            Toast.makeText(this, "Floating solver started.", Toast.LENGTH_SHORT).show();
        }
    }
}
