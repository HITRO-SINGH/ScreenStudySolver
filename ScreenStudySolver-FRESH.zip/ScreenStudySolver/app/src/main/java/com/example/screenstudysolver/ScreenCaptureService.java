package com.example.screenstudysolver;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenCaptureService extends Service {
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final int NOTIF_ID = 7001;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread imageThread;
    private Handler imageHandler;
    private WindowManager windowManager;
    private View overlay;
    private TextView answerView;
    private TextView ocrView;
    private TextRecognizer recognizer;
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private volatile boolean auto = true;
    private volatile boolean manualScan = false;
    private volatile long lastScanAt = 0L;

    @Override public void onCreate() {
        super.onCreate();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultData == null || resultCode != Activity.RESULT_OK) return START_NOT_STICKY;
        startForegroundCompat();
        showOverlay();
        startProjection(resultCode, resultData);
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Notification n = new Notification.Builder(this, "solver")
                .setContentTitle("Screen Study Solver")
                .setContentText("Screen reading is active")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("solver", "Screen Solver", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 14, 18, 14);
        box.setBackgroundColor(0xEE111827);

        LinearLayout bar = new LinearLayout(this);
        TextView title = new TextView(this);
        title.setText("⚡ Screen Solver"); title.setTextColor(Color.WHITE); title.setTextSize(16); title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button close = new Button(this); close.setText("X");
        bar.addView(close, new LinearLayout.LayoutParams(70, 55));
        box.addView(bar);

        answerView = new TextView(this);
        answerView.setText("Answer: —"); answerView.setTextColor(0xFF7CFF9B); answerView.setTextSize(22); answerView.setPadding(0, 10, 0, 6);
        box.addView(answerView);
        ocrView = new TextView(this);
        ocrView.setText("OCR: waiting…"); ocrView.setTextColor(0xFFCBD5E1); ocrView.setTextSize(12); box.addView(ocrView);

        LinearLayout controls = new LinearLayout(this);
        Button scan = new Button(this); scan.setText("SCAN");
        Button autoBtn = new Button(this); autoBtn.setText("AUTO: ON");
        controls.addView(scan, new LinearLayout.LayoutParams(0, 55, 1));
        controls.addView(autoBtn, new LinearLayout.LayoutParams(0, 55, 1));
        box.addView(controls);

        close.setOnClickListener(v -> stopSelf());
        scan.setOnClickListener(v -> requestScan());
        autoBtn.setOnClickListener(v -> { auto = !auto; autoBtn.setText(auto ? "AUTO: ON" : "AUTO: OFF"); });

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END; lp.x = 12; lp.y = 120;
        bar.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float downX, downY;
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX=lp.x; startY=lp.y; downX=e.getRawX(); downY=e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x=startX-(int)(e.getRawX()-downX);
                    lp.y=startY+(int)(e.getRawY()-downY);
                    if (windowManager != null && overlay != null) windowManager.updateViewLayout(overlay, lp);
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
        overlay = box;
        windowManager.addView(overlay, lp);
    }

    private void requestScan() { manualScan = true; }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void startProjection(int resultCode, Intent data) {
        MediaProjectionManager mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        if (projection == null) return;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int width = dm.widthPixels, height = dm.heightPixels, dpi = dm.densityDpi;
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageThread = new HandlerThread("screen-capture"); imageThread.start(); imageHandler = new Handler(imageThread.getLooper());
        imageReader.setOnImageAvailableListener(reader -> processLatest(reader), imageHandler);
        virtualDisplay = projection.createVirtualDisplay("ScreenStudySolver", width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, imageHandler);
    }

    private void processLatest(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (!auto && !manualScan) { image.close(); return; }
            if (now - lastScanAt < 900 && !manualScan) { image.close(); return; }
            if (scanning.getAndSet(true)) return;
            lastScanAt = now;
            manualScan = false;
            Image finalImage = image;
            Bitmap bitmap = imageToBitmap(finalImage);
            finalImage.close(); image = null;
            if (bitmap == null) { scanning.set(false); return; }
            InputImage input = InputImage.fromBitmap(bitmap, 0);
            recognizer.process(input).addOnSuccessListener(text -> {
                String raw = text.getText().replace('\n',' ').trim();
                runOnMain(() -> {
                    if (ocrView != null) ocrView.setText(raw.isEmpty() ? "OCR: no text" : "OCR: " + raw);
                    if (answerView != null) answerView.setText("Answer: " + MathSolver.solve(raw));
                });
            }).addOnFailureListener(e -> runOnMain(() -> { if (ocrView != null) ocrView.setText("OCR failed"); }))
              .addOnCompleteListener(t -> scanning.set(false));
        } catch (Throwable t) {
            scanning.set(false);
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer(); buffer.rewind();
        int pixelStride = plane.getPixelStride(); int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * image.getWidth();
        Bitmap bmp = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, image.getWidth(), image.getHeight());
        bmp.recycle();
        return cropped;
    }

    private void runOnMain(Runnable r) { new Handler(Looper.getMainLooper()).post(r); }

    @Override public void onDestroy() {
        if (virtualDisplay != null) virtualDisplay.release();
        if (projection != null) projection.stop();
        if (imageReader != null) imageReader.close();
        if (imageThread != null) imageThread.quitSafely();
        if (recognizer != null) recognizer.close();
        if (overlay != null && windowManager != null) windowManager.removeView(overlay);
        overlay = null;
        stopForeground(true);
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
