SCREEN STUDY SOLVER - PHONE BUILD

This is a clean Android project for study/practice:
- floating overlay
- Android screen-capture permission
- OCR using bundled ML Kit
- basic arithmetic, linear and quadratic solving
- no automatic clicking/typing in other apps

PHONE BUILD:
1. Create a new empty GitHub repository.
2. Upload the ZIP file to the repository root.
3. Create this workflow file:
   .github/workflows/build.yml
4. Paste the workflow code supplied with this project / build-workflow.txt.
5. Commit.
6. Open Actions and wait for a green run.
7. Download the APK artifact.

The CI uses Android Gradle Plugin 9.4.0 with Gradle 9.6.0 and JDK 17.
